<?php
	session_start();
	$_SESSION['language'] = "english";

	if(isset($_POST['wp-submit']))
	{
		$send = true;
		$language = $_POST['language'];
		$_SESSION['language'] = $language;
		$services = "";
		$source = "";
		$target = "";
		$name = "";
		$phone = "";
		$email = "";

		if(isset($_POST['services']))
		{
			$services = $_POST['services'];
		}
		else
		{
			$send = false;
		}

		if(!empty($_POST['source']))
		{
			$source = $_POST['source'];
		}
		else{
			$send = false;
		}

		if(!empty($_POST['target']))
		{
			$target = $_POST['target'];
		}
		else{
			$send = false;
		}

		if(!empty($_POST['name']))
		{
			$name = $_POST['name'];
		}
		else{
			$send = false;
		}

		if(!empty($_POST['phone']))
		{
			$phone = $_POST['phone'];
		}
		else{
			$send = false;
		}

		if(!empty($_POST['email']))
		{
			$email = $_POST['email'];
		}
		else{
			$send = false;
		}

		$message = $_POST['message'];
		$date = $_POST['date'];
		$deliverydate = date("M d, Y", strtotime($date));
		$uploadedfile = "";

		if(!empty($_FILES['customfile']['name']))
		{
			$filename = $_FILES['customfile']['name'];
			$ext = pathinfo($filename, PATHINFO_EXTENSION);
			$extensions = array('xls', 'ppt', 'docx', 'otx', 'xslx', 'xltx', 'pptx', 'pdf', 'xml', 'html', 'txt', 'mp3', 'wav', 'mid', 'mp4', 'avi', '3gp', 'flv');

			if(($_FILES['customfile']['size'] < 20971520) && (in_array($ext,$extensions)))
			{
				move_uploaded_file($_FILES['customfile']['tmp_name'], "files/" . basename($filename));
			}
			else
			{
				$uploadedfile = "invalid";
				$send = false;
			}

			$directory = "https://honyakuservices.000webhostapp.com/files/" . basename($filename);
		}
		else
		{
			$uploadedfile = "no file";
			$send = false;
		}

		if($send == true)
		{
			$to = "sales@honyakuservices.com";
			if($language === "english")
			{
				$subject = "Request";
			}
			if($language === "japanese")
			{
				$subject = "リクエスト";
			}

			if($language === "english")
			{
				$content = "<b>Name:</b><br/>" . $name . "<br/><br/><b>Phone:</b><br/>" . $phone . "<br/><br/><b>Email:</b><br/>" . $email . "<br/><br/><b>Services:</b><br/>" . $services . "<br/><br/><b>Source:</b><br/>" . $source . "<br/><br/><b>Target:</b><br/>" . $target . "<br/><br/><b>Delivery Deadline:</b><br/>" . $deliverydate . "<br/><br/><b>Project File:</b><br/><a href='" . $directory . "'>" . basename($filename) . "</a><br/><br/><b>Message:</b><br/>" . $message;
			}

			if($language === "japanese")
			{
				$content = "<b>名前:</b><br/>" . $name . "<br/><br/><b>電話:</b><br/>" . $phone . "<br/><br/><b>Eメール:</b><br/>" . $email . "<br/><br/><b>サービス:</b><br/>" . $services . "<br/><br/><b>ソース:</b><br/>" . $source . "<br/><br/><b>目標:</b><br/>" . $target . "<br/><br/><b>納期:</b><br/>" . $deliverydate . "<br/><br/><b>プロジェクトファイル:</b><br/><a href='" . $directory . "'>" . basename($filename) . "</a><br/><br/><b>メッセージ:</b><br/>" . $message;
			}

			$headers = "MIME-Version: 1.0" . "\r\n";
			$headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
			$headers .= "Reply-To: " . $email . "\r\n";

			mail($to,$subject,$content,$headers);
		}
	}	
?>
<!DOCTYPE html>
<html>
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
	
	<!-- Required meta tags -->
	
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	<title>Contact Form - Honyaku Services</title>

	<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="css/bootstrap-datepicker.min.css">
	<link rel="stylesheet" type="text/css" href="css/form.css">
</head>
<body>
<div id="language_switch">
	<a href="#" class="lang_eng">&nbsp;</a>
	<a href="#" class="lang_jap">&nbsp;</a>
</div>		
<section class="form-section">
	<div class="top_info">
	<div class="contact-info">
		<p class="mb-0">
		<span class="d-inline-block"><span class="english">Contact:</span><span class="japanese">連絡先：</span></span>
		
		<span class="d-inline-block">
			<a href="tel:+0091 7019619169">+0091 7019619169</a><br />
			<a href="tel:+0091 8837476812">+0091 8837476812</a>
		</span>
		</p>
		<p><span class="english">Email:</span>
			<span class="japanese">Eメール：</span>
			<a href="mailto:sales@honyakuservices.com">sales@honyakuservices.com</a>
		</p>
	</div>
	<div class="form-info-title english">
		Our priority is to secure customer data safe and committed to assure the protection and confidentiality of our client's data.
	</div>
	<div class="form-info-title japanese">
		お客様のデータを保護し、弊社の間でやり取りするデータは全てのプライバシー保護すること
		で安全を確保と守秘義務を誓約しています。
	</div>
</div>
	<?php
		if(isset($_POST['wp-submit']))
		{
			if($send == true)
			{
				if($language === "english")
				{
					echo '<p style="text-align: center; font-size: 22px; margin-bottom: 40px;">Thank you, your information has been sent!</p>';
				}
				if($language === "japanese")
				{
					echo '<p style="text-align: center; font-size: 22px; margin-bottom: 40px;">ありがとう、あなたの情報が送られました！</p>';
				}
			}
		}
	?>
	<form method="POST" action="" enctype="multipart/form-data">
		<input type="hidden" name="language" id="language" value="<?php echo $_SESSION['language']; ?>">
		<div class="row">
			<div class="col-md-2">
				<div class="box">
				<h4 class="english">Services</h4>
				<h4 class="japanese">サービス</h4>
				<div class="form-check english">
				  <input class="form-check-input" type="radio" name="services" id="Translation" value="Translation" <?php if(isset($_POST['wp-submit'])){ if($send == false){ if($services === "Translation"){ echo 'checked'; }}}?>>
				  <label class="form-check-label english" for="Translation">
				   	Translation
				  </label>
				</div>
				<div class="form-check english">
				  <input class="form-check-input" type="radio" name="services" id="Interpreter" value="Interpreter" <?php if(isset($_POST['wp-submit'])){ if($send == false){ if($services === "Interpreter"){ echo 'checked'; }}}?>>
				  <label class="form-check-label english" for="Interpreter">
				   	Interpreter
				  </label>
				</div>
				<div class="form-check english">
				  <input class="form-check-input" type="radio" name="services" id="Transcribing" value="Transcribing" <?php if(isset($_POST['wp-submit'])){ if($send == false){ if($services === "Transcribing"){ echo 'checked'; }}}?>>
				  <label class="form-check-label english" for="Transcribing">
				   	Transcribing
				  </label>
				</div>
				<div class="form-check english">
				  <input class="form-check-input" type="radio" name="services" id="Localization" value="Localization" <?php if(isset($_POST['wp-submit'])){ if($send == false){ if($services === "Localization"){ echo 'checked'; }}}?>>
				  <label class="form-check-label english" for="Localization">
				   	Localization
				  </label>
				</div>
				<div class="form-check english">
				  <input class="form-check-input" type="radio" name="services" id="Subtitling" value="Subtitling" <?php if(isset($_POST['wp-submit'])){ if($send == false){ if($services === "Subtitling"){ echo 'checked'; }}}?>>
				  <label class="form-check-label english" for="Subtitling">
				   	Subtitling
				  </label>
				</div>
				<div class="form-check english">
				  <input class="form-check-input" type="radio" name="services" id="Proofreading" value="Proofreading" <?php if(isset($_POST['wp-submit'])){ if($send == false){ if($services === "Proofreading"){ echo 'checked'; }}}?>>
				  <label class="form-check-label english" for="Proofreading">
				   	Proofreading
				  </label><br/><br/>
				  <span class="english"><?php if(isset($_POST['wp-submit'])){ if(empty($services)){ echo 'Please select a service'; }}?></span>
				</div>
				<div class="form-check japanese">
				  <input class="form-check-input" type="radio" name="services" id="Translation" value="翻訳" <?php if(isset($_POST['wp-submit'])){ if($send == false){ if($services === "翻訳"){ echo 'checked'; }}}?>>
				  <label class="form-check-label japanese" for="Translation">
				   	翻訳
				  </label>
				</div>
				<div class="form-check japanese">
				  <input class="form-check-input" type="radio" name="services" id="Interpreter" value="通訳" <?php if(isset($_POST['wp-submit'])){ if($send == false){ if($services === "通訳"){ echo 'checked'; }}}?>>
				  <label class="form-check-label japanese" for="Interpreter">
				   	通訳
				  </label>
				</div>
				<div class="form-check japanese">
				  <input class="form-check-input" type="radio" name="services" id="Transcribing" value="書き換える" <?php if(isset($_POST['wp-submit'])){ if($send == false){ if($services === "書き換える"){ echo 'checked'; }}}?>>
				  <label class="form-check-label japanese" for="Transcribing">
				   	書き換える
				  </label>
				</div>
				<div class="form-check japanese">
				  <input class="form-check-input" type="radio" name="services" id="Localization" value="ローカライズ" <?php if(isset($_POST['wp-submit'])){ if($send == false){ if($services === "ローカライズ"){ echo 'checked'; }}}?>>
				  <label class="form-check-label japanese" for="Localization">
				   	ローカライズ
				  </label>
				</div>
				<div class="form-check japanese">
				  <input class="form-check-input" type="radio" name="services" id="Subtitling" value="字幕翻訳" <?php if(isset($_POST['wp-submit'])){ if($send == false){ if($services === "字幕翻訳"){ echo 'checked'; }}}?>>
				  <label class="form-check-label japanese" for="Subtitling">
				   	字幕翻訳
				  </label>
				</div>
				<div class="form-check japanese">
				  <input class="form-check-input" type="radio" name="services" id="Proofreading" value="プルーフリーディング" <?php if(isset($_POST['wp-submit'])){ if($send == false){ if($services === "プルーフリーディング"){ echo 'checked'; }}}?>>
				  <label class="form-check-label japanese" for="Proofreading">
				   	プルーフリーディング
				  </label><br/><br/>
				  <span class="japanese"><?php if(isset($_POST['wp-submit'])){ if(empty($services)){ echo 'サービスを選択してください'; }}?></span>
				</div>
			</div>
			</div>

			<div class="col-md-3">
				<div class="box">
				<h4 class="english">Language Pair</h4>
				<h4 class="japanese">言語ペア</h4>
				<div class="form-group">
				    <label for="Source" class="english">Source*</label>
				    <label for="Source" class="japanese">原文言語 *</label>
				    <select class="form-control" id="Source" name="source">
						<option value="English" class="english" <?php if(isset($_POST['wp-submit'])){ if($send == false){ if($source === "English"){ echo 'selected'; }}}?>>English</option>
						<option value="英語" class="japanese" <?php if(isset($_POST['wp-submit'])){ if($send == false){ if($source === "英語"){ echo 'selected'; }}}?>>英語</option>
						<option value="Japanese" class="english" <?php if(isset($_POST['wp-submit'])){ if($send == false){ if($source === "Japanese"){ echo 'selected'; }}}?>>Japanese</option>
						<option value="日本語" class="japanese" <?php if(isset($_POST['wp-submit'])){ if($send == false){ if($source === "日本語"){ echo 'selected'; }}}?>>日本語</option>
						<option value="Chinese" class="english" <?php if(isset($_POST['wp-submit'])){ if($send == false){ if($source === "Chinese"){ echo 'selected'; }}}?>>Chinese (Simplified)</option>
						<option value="中国語（簡体字）" class="japanese" <?php if(isset($_POST['wp-submit'])){ if($send == false){ if($source === "中国語（簡体字）"){ echo 'selected'; }}}?>>中国語（簡体字）</option>
				    </select>
				  </div>
				  <div class="form-group">
				    <label for="Target" class="english">Target*</label>
				    <label for="Target" class="japanese">目標 *</label>
				    <select class="form-control" id="Target" name="target">
						<option value="English" class="english" <?php if(isset($_POST['wp-submit'])){ if($send == false){ if($target === "English"){ echo 'selected'; }}}?>>English</option>
						<option value="英語" class="japanese" <?php if(isset($_POST['wp-submit'])){ if($send == false){ if($target === "英語"){ echo 'selected'; }}}?>>英語</option>
						<option value="Japanese" class="english" <?php if(isset($_POST['wp-submit'])){ if($send == false){ if($target === "Japanese"){ echo 'selected'; }}}?>>Japanese</option>
						<option value="日本語" class="japanese" <?php if(isset($_POST['wp-submit'])){ if($send == false){ if($target === "日本語"){ echo 'selected'; }}}?>>日本語</option>
						<option value="Chinese" class="english" <?php if(isset($_POST['wp-submit'])){ if($send == false){ if($target === "Chinese"){ echo 'selected'; }}}?>>Chinese (Simplified)</option>
						<option value="中国語（簡体字）" class="japanese" <?php if(isset($_POST['wp-submit'])){ if($send == false){ if($target === "中国語（簡体字）"){ echo 'selected'; }}}?>>中国語（簡体字）</option>
				    </select>
				  </div>
				  <div class="form-group">
				    <label for="name" class="english">Name*</label>
				    <label for="name" class="japanese">お名前 *</label>
				    <input class="form-control" type="text" name="name" value="<?php if(isset($_POST['wp-submit'])){ if($send == false){ echo $name; }}?>">
					<span class="english"><?php if(isset($_POST['wp-submit'])){ if(empty($name)){ echo '<br/>Please enter your name'; }}?></span>
					<span class="japanese"><?php if(isset($_POST['wp-submit'])){ if(empty($name)){ echo '<br/>名前を入力してください'; }}?></span>
				  </div>
				  <div class="form-group">
				    <label for="phone" class="english">Phone*</label>
				    <label for="phone" class="japanese">電話番号 *</label>
				    <input class="form-control" type="number" name="phone" value="<?php if(isset($_POST['wp-submit'])){ if($send == false){ echo $phone; }}?>">
					<span class="english"><?php if(isset($_POST['wp-submit'])){ if(empty($phone)){ echo '<br/>Please enter your phone'; }}?></span>
					<span class="japanese"><?php if(isset($_POST['wp-submit'])){ if(empty($phone)){ echo '<br/>電話を入力してください'; }}?></span>
				  </div>
				  <div class="form-group">
				    <label for="email" class="english">Email*</label>
				    <label for="email" class="japanese">電子メール *</label>
				    <input class="form-control" type="email" name="email" value="<?php if(isset($_POST['wp-submit'])){ if($send == false){ echo $email; }}?>">
					<span class="english"><?php if(isset($_POST['wp-submit'])){ if(empty($email)){ echo '<br/>Please enter your email'; }}?></span>
					<span class="japanese"><?php if(isset($_POST['wp-submit'])){ if(empty($email)){ echo '<br/>あなたのメールアドレスを入力してください'; }}?></span>
				  </div>
				</div>
			</div>
			<div class="col-md-4">
				<div class="box">
				<h4 class="english">Project File</h4>
				<h4 class="japanese">プロジェクトファイル</h4>
				<div class="form-group">
				<label class="english">Drop Source Document/Video*</label>
				<label class="japanese">ここに原稿・ビデオをドラッグアンドドロップ *</label>
				<div class="custom-file">
				  <input type="file" class="custom-file-input" id="customFile" name="customfile">
				  <?php if(isset($_POST['wp-submit'])){ if($uploadedfile === "no file"){ echo '<br/><span class="english">Please select a file</span><span class="japanese">ファイルを選択してください</span>'; } if($uploadedfile === "invalid"){ echo '<br/><span class="english">Invalid file. You file must have less than 20MB in size and be in one of the formats allowed.</span><span class="japanese">無効なファイル。 ファイルのサイズは20MB未満で、許可されている形式のいずれかである必要があります。</span>'; }}?>
				  <label class="custom-file-label english" for="customFile">No file chosen</label>
				  <label class="custom-file-label japanese" for="customFile">ファイルが選択されていません</label>
				  <small class="english">Maximum filesize: 20MB Allowed extensions: xls, ppt, docx, otx, xslx, xltx, pptx, pdf, xml, html, txt, mp3, wav, mid, mp4, avi, 3gp, flv</small>
				  <small class="japanese">最大ファイルサイズ：20MB許可される拡張子：xls、ppt、docx、otx、xslx、xltx、pptx、pdf、xml、html、txt、mp3、wav、mid、mp4、avi、3gp、flv</small>
				</div>
			</div>
				<div class="form-group">
				    <label for="message" class="english">Message</label>
				    <label for="message" class="japanese">メッセージ</label>
				    <textarea class="form-control" id="message" name="message" rows="5"><?php if(isset($_POST['wp-submit'])){ if($send == false){ echo $message; }}?></textarea>
				  </div>
				  <div class="form-group text-right">
				    <input type="submit" name="wp-submit" id="wp-submit" class="btn bg-dark text-white no-box-shadow english" value="Submit">
				    <input type="submit" name="wp-submit" id="wp-submit" class="btn bg-dark text-white no-box-shadow japanese" value="送信する">
				  </div>
				</div>
			</div>
			<div class="col-md-3">
				<div class="box">
				<h4 class="english">Delivery Deadline</h4>
				<h4 class="japanese">ご希望納期</h4>
				<div class="form-group">
					<input type="date" name="date" style="width: 100%;" value="<?php if(isset($_POST['wp-submit'])){ if($send == false){ echo $date; }}?>">
				</div>
		</div>
	</form>
</section>
<script type="text/javascript" src="js/jquery-3.5.1.min.js"></script>
<script src="https://use.fontawesome.com/75e38a9c1f.js"></script>
<script type="text/javascript" src="js/bootstrap.min.js"></script>

<script type="text/javascript" src="js/bootstrap-datepicker.min.js"></script>
<script src="js/init.js"></script>
<script type="text/javascript">
	$(document).ready(function(){
		$('.lang_eng').click(function(){
			$('.japanese').hide();
			$('.english').show();
		})
		$('.lang_jap').click(function(){
			$('.english').hide();
			$('.japanese').show();
			$('#language').val('japanese');
			$('#Source option:eq(0)').text('英語');
			$('#Target option:eq(0)').text('英語');
		})
		$('#customFile').on('change',function(){
			var file = $('#customFile').val().match(/[^\\/]*$/)[0];;
			$('.custom-file-label').text(file);
		})
		var language = "<?php if(isset($_POST['wp-submit'])){ echo $language; }?>";
		if(language == "japanese")
		{
			$('.english').hide();
			$('.japanese').show();
		}
	})
</script>
</body>
</html>
